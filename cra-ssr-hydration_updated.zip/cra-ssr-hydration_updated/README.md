# CRA SSR Hydration Example

This project demonstrates server-side rendering (SSR) of the Login page and client-side rendering (CSR) of other pages using Create React App + TypeScript + Express.

## How to Run

1. Install dependencies:

```
npm install
```

2. Build the client app:

```
npm run build
```

3. Start the server:

```
npm run server
```

4. Visit:

- `http://localhost:3000/login` (SSR Login Page)
- `http://localhost:3000/dashboard` (CSR Dashboard)
- `http://localhost:3000/profile` (CSR Profile)

---