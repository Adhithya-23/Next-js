import React from "react";

const Dashboard: React.FC = () => {
  console.log("Dashboard");
  return <h2>Dashboard (Client-side)</h2>;
};

export default Dashboard;
