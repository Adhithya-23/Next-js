import React from 'react';

const Profile: React.FC = () => {
  return <h2>Profile (Client-side)</h2>;
};

export default Profile;