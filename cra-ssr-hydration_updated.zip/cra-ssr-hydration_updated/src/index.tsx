import React from 'react';
import { createRoot, hydrateRoot } from 'react-dom/client';
import App from './App';

const rootElement = document.getElementById('root');

if (rootElement?.hasChildNodes()) {
  hydrateRoot(rootElement, <App />);
} else if (rootElement) {
  createRoot(rootElement).render(<App />);
}