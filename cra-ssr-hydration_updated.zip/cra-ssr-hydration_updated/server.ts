import express, { Request, Response } from "express";
import path from "path";
import fs from "fs";
import React from "react";
import ReactDOMServer from "react-dom/server";
import { fileURLToPath } from "url";
import Login from "./src/components/Login";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3007;

app.use(express.static(path.resolve(__dirname, "build")));

app.get("/login", (req: Request, res: Response) => {
  const loginHtml = ReactDOMServer.renderToString(React.createElement(Login));

  const indexFile = path.resolve(__dirname, "build", "index.html");

  fs.readFile(indexFile, "utf8", (err, data) => {
    if (err) {
      console.error("Could not read index.html", err);
      return res.status(500).send("Internal Server Error");
    }

    const htmlWithLogin = data.replace(
      '<div id="root"></div>',
      `<div id="root">${loginHtml}</div>`
    );

    return res.send(htmlWithLogin);
  });
});

app.get("*", (req: Request, res: Response) => {
  res.sendFile(path.resolve(__dirname, "build", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Server is listening on port ${PORT}`);
});
